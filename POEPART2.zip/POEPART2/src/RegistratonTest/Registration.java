package RegistratonTest;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Registration {

    private User user;
    private POEPART2 program;

    public Registration(POEPART2 program) {
        this.program = program;
    }

    public void execute() {
        String name;
        String surname;
        String username;
        String password;
        boolean validInformation = false;
        
        while (!validInformation){
            // Create a panel to hold the input fields
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            // Add input fields for Name, Surname, Username, and Password
            JTextField nameField = new JTextField(10);
            JTextField surnameField = new JTextField(10);
            JTextField usernameField = new JTextField(10);
            JPasswordField passwordField = new JPasswordField(10);

            panel.add(new JLabel("Name:"));
            panel.add(nameField);
            panel.add(new JLabel("Surname:"));
            panel.add(surnameField);
            panel.add(new JLabel("Username (Must include 5 characters and underscore)"));
            panel.add(usernameField);
            panel.add(new JLabel("Password (Must include 8 characters with special character, number, and capital letter)"));
            panel.add(passwordField);

            // Create buttons for Submit and Cancel
            int result = JOptionPane.showConfirmDialog(null, panel, "Enter Information", JOptionPane.OK_CANCEL_OPTION);

            // If Submit button is clicked
            if (result == JOptionPane.OK_OPTION) {
                // Retrieve values from input fields
                name = nameField.getText();
                surname = surnameField.getText();
                username = usernameField.getText();
                password = new String(passwordField.getPassword());
                
                // Checking when the user puts in the right username or password
                if (Login.isValidUsername(username) && Login.isValidPassword(password)){
                    user = new User(username,password);
                    JOptionPane.showMessageDialog(null, "Registration is successful!");
                    validInformation = true;

                    // Update the registration status
                    program.setRegistered(true);

                    // Prompting the user to continue to Login or cancel
                    int loginChoice = JOptionPane.showOptionDialog(null,
                            "Do you want to continue to Login?",
                            "Login Option",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new String[]{"Login","Cancel"},
                            "Login");

                    if(loginChoice == JOptionPane.YES_OPTION){
                        // Automatically prompt login after successful register
                        Login login = new Login();
                        if (login.register()) {
                            program.showMainMenu();
                        }
                    } else{
                        JOptionPane.showMessageDialog(null, "Goodbye!");
                        System.exit(0);
                    }
                // if user puts in the incorrect credentials     
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password! Please try again.");
                }
            } else {
                // User clicked Cancel
                return;
            }
        }
    }

    boolean login(String invalid_username, String invalid_password) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    User getUser() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
      
