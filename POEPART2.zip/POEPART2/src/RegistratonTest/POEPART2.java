package RegistratonTest;

import javax.swing.*;

class POEPART2 {

    private boolean isRegistered = false;  // Track if the user has registered

    public static void main(String[] args) {
        // Creating instanc-e to call non-static methods
        POEPART2 program = new POEPART2();
        program.showInitialDialog();
    }

    // Method to show the initial dialog with options
    public void showInitialDialog() {
        String[] options = {"Register", "Login", "Cancel"};
        int choice = JOptionPane.showOptionDialog(null,
                "Welcome! Please choose an option:",
                "Welcome",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]);

        switch (choice) {
            case 0:
                // Register
                Registration signUp = new Registration(this);
                signUp.execute();
                break;

            case 1:
                // Login
                if (isRegistered) {
                    Login login = new Login();
                    if (login.register()) {
                        // Display main menu after successful login
                        showMainMenu();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You need to register before you log in!");
                }
                break;
                
            case 2:
            default:
                // Cancel or close the dialog
                JOptionPane.showMessageDialog(null, "Goodbye!");
                System.exit(0);
                break;
        }
    }

    public void showMainMenu() {
        int response = JOptionPane.showOptionDialog(null, "Welcome to EasyKanban", "Welcome",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, new Object[]{"Proceed"}, "Proceed");

        if (response == 0) {
            boolean running = true;

            while (running) {
                String[] options = {"Add tasks", "Show report", "Quit"};
                int choice = JOptionPane.showOptionDialog(null,
                        "Please choose an option:",
                        "Main Menu",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.INFORMATION_MESSAGE,
                        null,
                        options, options[0]);

                switch (choice) {
                    case 0:
                        // Adding Tasks
                        TaskManager taskManager = new TaskManager();
                        taskManager.addTasks();
                        break;

                    case 1:
                        // Showing report
                        JOptionPane.showMessageDialog(null, "Coming Soon");
                        break;

                    case 2:
                    default:
                        // Quit
                        JOptionPane.showMessageDialog(null, "Goodbye!");
                        running = false;
                        break;
                }
            }
        }
    }

    public void setRegistered(boolean isRegistered) {
        this.isRegistered = isRegistered;
    }
}
 