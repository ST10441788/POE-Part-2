package RegistratonTest;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class TaskManager {
    private List<Task> tasks = new ArrayList<>();
    private int totalDuration = 0;
    
    public void addTasks() {
        String input = JOptionPane.showInputDialog(null, "How many tasks would you like to enter?");
        int numberOfTasks;

        try {
            numberOfTasks = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number. Please enter a valid number of tasks.");
            return;
        }

        for (int j = 0; j < numberOfTasks; j++) {
            Task task = captureTask(j);
            if (task != null) {
                tasks.add(task);
                totalDuration += task.getDuration();
                JOptionPane.showMessageDialog(null, task.printTaskDetails());
            }
        }

        JOptionPane.showMessageDialog(null, "Total duration of all tasks: " + totalDuration + " hours.");
    }

    private Task captureTask(int taskNumber) {
        String taskName = JOptionPane.showInputDialog(null, "Enter the task name:");
        if (taskName == null) return null;

        String taskDescription = JOptionPane.showInputDialog(null, "Enter the description (max 50 characters):");
        if (taskDescription == null) return null;

        if (taskDescription.length() > 50) {
            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
            return null;
        }

        String developerDetails = JOptionPane.showInputDialog(null, "Enter the developer's full name:");
        if (developerDetails == null) return null;

        String durationInput = JOptionPane.showInputDialog(null, "Enter the task duration in hours:");
        if (durationInput == null) return null;

        int taskDuration;
        try {
            taskDuration = Integer.parseInt(durationInput);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid duration. Please enter a valid number of hours.");
            return null;
        }

        String[] statusOptions = {"To Do", "Doing", "Done"};
        int statusChoice = JOptionPane.showOptionDialog(null,
                "Select the task status:",
                "Task Status",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                statusOptions,
                statusOptions[0]);

        if (statusChoice == JOptionPane.CLOSED_OPTION) return null;

        String taskStatus = statusOptions[statusChoice];
        Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus);

        return task;
    }
}
