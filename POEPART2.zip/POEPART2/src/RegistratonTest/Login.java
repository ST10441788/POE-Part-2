package RegistratonTest;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class Login {
    private User user;
    
    public boolean register(){
        String username;
        String password;
        boolean validInformation = false;
        
        //prompting the if statements to check if the user inputed the crorrect Credentials after signing up.
        while (!validInformation){
            username = JOptionPane.showInputDialog(null, "Provide your Username (Must include 5 characters and underscore):");
            JPasswordField passwordField = new JPasswordField();
            int option = JOptionPane.showConfirmDialog(null, passwordField, "Provide your password ", JOptionPane.OK_CANCEL_OPTION);
            
             // User clicked cancel or closed the dialog, end the program
            if(username == null || option != JOptionPane.OK_OPTION) {
                return false;
            }
            
            password = new String(passwordField.getPassword());
            
             // End the program if username is empty
            if(username.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Invalid username! Username cannot be empty.");
                continue;
            }
            
            if (isValidUsername(username) && isValidPassword(password)) {
                user = new User(username, password);
                JOptionPane.showMessageDialog(null, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                return true; // if login is successful
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password! Please try again");
                // End the program if username or password is invalid
            }
        }
        return false;
    }
   
    //promptng the username length and username specifications
    public static boolean isValidUsername(String username) {
        return username != null && username.contains("_") && username.length() >= 5 ;
    }

    //promptng the password length and password specifications 
    public static boolean isValidPassword(String password){
        if (password.length() < 8)
            return false;
        
        boolean hasUpperCase = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        
        for (char ch : password.toCharArray()){
            if (Character.isUpperCase(ch)){
                hasUpperCase= true;
            } else if (Character.isDigit(ch)){
                hasNumber = true;
            } else if (isSpecialCharacter(ch)){
                hasSpecialChar = true;
            }
        }
        
        return hasUpperCase && hasNumber && hasSpecialChar;
    }
             
    public static boolean isSpecialCharacter(char ch){
        String specialCharacters = "!£$%^&*()_-+={[}]~#:@;'<,>.?/";
        return specialCharacters.contains(String.valueOf(ch));
    }
             
    public User getUser(){
        return user;
    }
}
