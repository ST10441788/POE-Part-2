package RegistratonTest;

public class Task {
    private String status;
    private String developerDetails;
    private int taskNumber;
    private String taskName;
    private String taskDescription;
    private String taskID;
    private int duration;

    private static int taskCounter = 0;

    public static void resetTaskCounter() {
        taskCounter = 0;
    }

    public Task(String taskName, String taskDescription, String developerDetails, int duration, String status) {
        this.taskNumber = taskCounter++;
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.duration = duration;
        this.status = status;
        this.taskID = createTaskID();
    }

    // Getters
    public String getStatus() {
        return status;
    }

    public String getDeveloperDetails() {
        return developerDetails;
    }

    public int getTaskNumber() {
        return taskNumber;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public String getTaskID() {
        return taskID;
    }

    public int getDuration() {
        return duration;
    }

    // Methods as per instruction
    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String devInitials = developerDetails.split(" ")[0].substring(0, 3).toUpperCase();
        return taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + devInitials;
    }

    public String printTaskDetails() {
        return "Task: " + taskName + "\n" +
               "Developer: " + developerDetails + "\n" +
               "Duration: " + duration + " hours\n" +
               "Task ID: " + taskID + "\n" +
               "Status: " + status;
    }

    public static int returnTotalHours(Task[] tasks) {
        int total = 0;
        for (Task task : tasks) {
            total += task.getDuration();
        }
        return total;
    }
}
