package RegistratonTest;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testGetStatus() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("To Do", task.getStatus());
    }

    @Test
    public void testGetDeveloperDetails() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("Robyn Harrison", task.getDeveloperDetails());
    }

    @Test
    public void testGetTaskNumber() {
        Task.resetTaskCounter();
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals(0, task.getTaskNumber());
    }

    @Test
    public void testGetTaskName() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("Login Feature", task.getTaskName());
    }

    @Test
    public void testGetTaskDescription() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("Create Login to authenticate users", task.getTaskDescription());
    }

    @Test
    public void testGetTaskID() {
        Task.resetTaskCounter();
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("LO:0:ROB", task.getTaskID());
    }

    @Test
    public void testGetDuration() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals(8, task.getDuration());
    }

    @Test
    public void testCheckTaskDescription() {
        Task validTask = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        Task invalidTask = new Task("Login Feature", "This is a very long task description that exceeds fifty characters limit", "Robyn Harrison", 8, "To Do");

        assertTrue(validTask.checkTaskDescription());
        assertFalse(invalidTask.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Task.resetTaskCounter();
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("LO:0:ROB", task.createTaskID());

        Task task2 = new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");
        assertEquals("AD:1:MIK", task2.createTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        String expectedDetails = "Task: Login Feature\nDeveloper: Robyn Harrison\nDuration: 8 hours";
        assertEquals(expectedDetails, task.printTaskDetails());
    }

    @Test
    public void testReturnTotalHours() {
        Task task1 = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        Task task2 = new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");

        Task[] tasks = {task1, task2};
        assertEquals(18, Task.returnTotalHours(tasks));
    }
}
